<section class="blog_header_banner_sec">
    <div class="container">
        <div class="deal_header_heading_sec">
            <div class="row">

                <div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-12">

                    <div class="blog_header_heading_left">

                        <h2>Planiversity <span>Blog</span></h2>

                        <p>Here, we aim to provide you with informative and engaging content on various topics.</p>

                    </div>

                </div>

                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">

                    <div class="banner-wrapper">
                        <img src="<?php echo SITE; ?>images/blog_image_main.png" alt="" class="banner_image" />
                    </div>

                </div>

            </div>

        </div>

    </div>


</section>