<footer class="footer position-relative text-left">
  <img src="<?php echo SITE; ?>assets/images/landingImage/part-3.png" alt="create route" class="footer-img">
  <div class="container">
    <div class="row footer-border-bottom">
      <div class="col-md-3">
        <p class="footer-title">Planiversity</p>
        <p class="footer-content">A revolutionary travel logistics</p>
        <p class="footer-content"> service, dedicated to consolidating</p>
        <p class="footer-content pb-5">so much of your travel information.</p>
        <div class="footer-social">
          <li><a href="https://twitter.com/planiversity" class=""><i class="fa fa-twitter"></i></a></li>
          <li><a href="https://www.facebook.com/Planiversity/" class=""><i class="fa fa-facebook"></i></a></li>
          <li><a href="https://www.instagram.com/planiversity/" class=""><i class="fa fa-instagram"></i></a></li>
          <li><a href="https://www.linkedin.com/company/planiversity/" class=""><i class="fa fa-linkedin"></i></a></li>
        </div>
      </div>
      <div class="col-md-6">

        <div class="footer_item2">
          <p class="footer-content-titile">Site map</p>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="<?php echo SITE; ?>contact-us">Contact Us</a>
          </div>
          <div class="footer-content-body">
            <!--<a class="footer-sitemap" target="_blank" href="http://erichrichardblog.wordpress.com">Blog</a>-->
            <a class="footer-sitemap" href="<?= SITE ?>faq">FAQs</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="<?= SITE ?>data-security">Data Security</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="<?php echo SITE; ?>what-you-get">What You'll get</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="https://www.planiversity.com/sitemap.xml">Sitemap</a>
          </div>
        </div>


        <div class="footer_item2">
          <p class="footer-content-titile">Legal</p>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="https://getterms.io/view/98sYm/privacy/en-us">Privacy Policy</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="https://getterms.io/view/98sYm/tos/en-us">Terms of Service</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="https://getterms.io/view/98sYm/cookie/en-us">Cookies</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="https://getterms.io/view/98sYm/aup/en-us">AUP</a>
          </div>
        </div>


        <div class="footer_item2">

          <p class="footer-content-titile">Quick Links</p>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="">Free Demo</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="<?= SITE ?>affiliate">Become an Affiliate</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="">Partners</a>
          </div>
          <div class="footer-content-body">
            <a class="footer-sitemap" href="https://planivers.com" target="_blank">Planivers Magazine</a>
          </div>

        </div>

      </div>

      <div class="col-md-3">
        <p class="footer-content-titile">Contacts</p>
        <p class="footer-content-text">Have a question? Need to get </p>
        <p class="footer-content-text">something off your chest?</p>
        <p class="footer-content-text">Email Us and we'll contact you...</p>
        <p class="footer-section3-text pt-4">4023 Kennett Pike</p>
        <p class="footer-section3-text">Suite 690</p>
        <p class="footer-section3-text">Wilmington, DE 19807</p>
        <div class="footer-section3-text pb-5 mb-3">
          <a class="footer-tag" href="mailto:plans@planiversity.com">plans@planiversity.com</a>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <p class="copyright">&copy; Copyright. 2015 - <?= date('Y'); ?>. Planiversity, LLC. All Rights Reserved.</p>
      </div>
    </div>
  </div>
</footer>

</div>
</div>
<!-- <script type="text/javascript">
  "use strict";

  ! function() {
    var t = window.driftt = window.drift = window.driftt || [];
    if (!t.init) {
      if (t.invoked) return void(window.console && console.error && console.error("Drift snippet included twice."));
      t.invoked = !0, t.methods = ["identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on"],
        t.factory = function(e) {
          return function() {
            var n = Array.prototype.slice.call(arguments);
            return n.unshift(e), t.push(n), t;
          };
        }, t.methods.forEach(function(e) {
          t[e] = t.factory(e);
        }), t.load = function(t) {
          var e = 3e5,
            n = Math.ceil(new Date() / e) * e,
            o = document.createElement("script");
          o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + n + "/" + t + ".js";
          var i = document.getElementsByTagName("script")[0];
          i.parentNode.insertBefore(o, i);
        };
    }
  }();
  drift.SNIPPET_VERSION = '0.3.1';
  drift.load('99c7am4huua5');
</script> -->
</body>

</html>