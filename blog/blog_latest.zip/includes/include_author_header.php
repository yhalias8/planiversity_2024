<?php
global $heading_title;
global $heading_description;
?>

<section class="blog_header_banner_sec page">
    <div class="container">
        <div class="blog_header_heading_sec page">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="blog_header_heading_left">

                        <h2> <?= $heading_title ?> <span>Author</span></h2>

                        <p><?= $heading_description ?></p>

                    </div>

                </div>



            </div>

        </div>

    </div>


</section>