<?php
global $heading_title;
?>

<section class="blog_header_banner_sec page">
    <div class="container">
        <div class="blog_header_heading_sec page">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="blog_header_heading_left">

                        <h1> <?= $heading_title ?> </h1>

                        <p>Here, we aim to provide you with informative and engaging content on various topics.</p>

                    </div>

                </div>



            </div>

        </div>

    </div>


</section>