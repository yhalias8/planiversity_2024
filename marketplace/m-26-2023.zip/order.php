<?php
session_start();
include_once("../config.ini.php");
$uuid = $_GET['uuid'];
$flag = "wish_redirect";
if ($uuid) {
    $_SESSION['service_uuid'] = $uuid;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Planiversity</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include_once("includes/include_head.php"); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/additional-methods.js"></script>
</head>

<body>

    <?php
    $heading_title = "Order";
    include_once("includes/include_order_header.php");
    ?>

    <section class="shopping-cart dark">
        <div class="container">

            <div class="mb-2">
                <button type="button" class="btn btn-info back_button"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button>
            </div>

            <div class="block-heading">
                <p>If you are a planiversity member, you will receive an additional 10% discount..</p>
            </div>
            <div class="content">
                <div class="row service_load">

                    <div class="loading_section" style="display: none;">
                        <i class="fa fa-spinner fa-spin"></i>
                    </div>

                    <div class="col-md-12 col-lg-8">
                        <div class="items">
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-4">
                        <div class="summary" style="display: none;">
                            <h3>Summary</h3>
                            <div class="summary-item"><span class="text">Subtotal</span><span class="price">$<span id="subtotal">0</span></span></div>
                            <div class="summary-item"><span class="text">Discount</span><span class="price">$0</span></div>
                            <div class="summary-item"><span class="text">Shipping</span><span class="price">$0</span></div>
                            <div class="summary-item"><span class="text">Total</span><span class="price total">$<span id="total">0</span></span></div>
                            <button type="button" class="btn btn-primary btn-lg btn-block e_button guest">Guest Checkout</button>
                            <button type="button" class="btn btn-primary btn-lg btn-block e_button member">Member Checkout</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="modal fade modal-blur" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-bottom-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-title text-center">
                        <h4>Login</h4>
                    </div>
                    <div class="d-flex flex-column text-center">

                        <form id="loginform" class="payment-form">
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                            </div>
                            <button type="submit" class="btn btn-info btn-block btn-round submit_button">Login</button>
                        </form>

                        <div class="text-center text-muted delimiter"></div>
                        <div class="d-flex justify-content-center social-buttons">

                        </div>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-center">
                    <div class="signup-section">Not a member yet? <a href="<?= SITE ?>registration" class="text-info"> Sign Up</a>.</div>
                </div>
            </div>
        </div>

        <?php include_once("includes/include_order_script.php"); ?>
        <?php include_once("includes/include_footer.php"); ?>

</body>

</html>