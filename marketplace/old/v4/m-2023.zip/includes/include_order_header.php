<section class="header_slider_sec order">
    <?php
    global $heading_title;
    include_once("includes/include_navbar.php");
    ?>
    <img src="<?= SITE; ?>/marketplace/images/background.png" class="header_banner_order">

    <div class="top_header_heading order">

        <div class="container">

            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">

                    <h2 class="order-heading"><?= $heading_title ?></h2>

                </div>


            </div>

        </div>

    </div>




</section>