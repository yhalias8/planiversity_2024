<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">

<link href="<?= SITE; ?>marketplace/css/search.css?v=2021212" rel="stylesheet">
<link href="<?= SITE; ?>marketplace/css/style.css?v=2021212" rel="stylesheet">
<link href="<?= SITE; ?>marketplace/css/responsive.css?v=202012" rel="stylesheet">