<?php include_once("include_script.php"); ?>


<script>
    $(function() {
        localStorageValueInitialized();
        localStorageWishValueInitialized();
    });
</script>